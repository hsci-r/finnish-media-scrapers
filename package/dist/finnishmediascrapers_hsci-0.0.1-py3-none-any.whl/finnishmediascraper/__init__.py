
def main():
    """Entry point for the application script"""
    print("Hello")
